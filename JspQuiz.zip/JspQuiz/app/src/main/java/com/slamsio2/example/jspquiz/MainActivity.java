package com.slamsio2.example.jspquiz;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private int level = 0;
    private ImageButton imgb;
    private RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgb = this.findViewById(R.id.imgButton);
        rg = this.findViewById(R.id.radiogroup);

        imgb.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        Intent unIntent = new Intent(this, activityQuestion.class);
        unIntent.putExtra("Niveau", level);
        int id = rg.getCheckedRadioButtonId();
        switch (id){
            case R.id.radioButton1:
                level = 1;
                this.startActivity(unIntent);
                break;
            case R.id.radioButton2:
                level = 2;
                this.startActivity(unIntent);
                break;
            case R.id.radioButton3:
                level = 3;
                this.startActivity(unIntent);
                break;
            case R.id.radioButton4:
                level = 4;
                this.startActivity(unIntent);
                break;
            case -1:
                Toast tot = Toast.makeText(getApplicationContext(), "Tu dois choisir un niveau", Toast.LENGTH_SHORT);
                tot.show();
                break;


        }
    }
}
