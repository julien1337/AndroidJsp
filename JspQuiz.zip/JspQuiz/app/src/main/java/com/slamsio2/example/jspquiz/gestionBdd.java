package com.slamsio2.example.jspquiz;

public class gestionBdd {
}
