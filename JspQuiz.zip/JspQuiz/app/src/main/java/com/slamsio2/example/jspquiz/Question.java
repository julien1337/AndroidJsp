package com.slamsio2.example.jspquiz;

public class Question {

    // PROPERTIES

    private int id;
    private String question;
    private String[] choix;
    private String reponse;

    // CONSTRUCTEURS

    public Question(int idQ, String questionQ, String[] choixQ, String reponseQ){
        this.id = idQ;
        this.question = questionQ;
        this.choix = choixQ;
        this.reponse = reponseQ;
    }

    public Question(){}

    // GETTERS

    public int getId(){
        return this.id;
    }

    public String getQuestion(){
        return this.question;
    }

    public String[] getChoix(){
        return this.choix;
    }

    public String getChoix(int num){
        return this.choix[num];
    }

    public String getReponse(){
        return this.reponse;
    }

    // SETTERS

    public void setId(int id) {
        this.id = id;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setChoix(String[] choix) {
        this.choix = choix;
    }

    public void setChoix(int num, String leChoix){
        this.choix[num] = leChoix;
    }

    public void setReponse(String reponse) {
        this.reponse = reponse;
    }
}
