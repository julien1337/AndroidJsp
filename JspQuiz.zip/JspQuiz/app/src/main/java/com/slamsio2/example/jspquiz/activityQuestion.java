package com.slamsio2.example.jspquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class activityQuestion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
    }
}
