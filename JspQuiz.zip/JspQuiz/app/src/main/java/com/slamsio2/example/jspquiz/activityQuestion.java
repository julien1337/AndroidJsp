package com.slamsio2.example.jspquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.RadioGroup;
import android.widget.TextView;

public class activityQuestion extends AppCompatActivity {

    private TextView quest;
    private TextView rep;
    private TextView lvlText;
    private RadioGroup rg;
    private String level;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);

        quest = this.findViewById(R.id.textQuestion);
        rep = this.findViewById(R.id.VraiFaux);
        lvlText = this.findViewById(R.id.levelText);
        rg = this.findViewById(R.id.reponsesGroup);
        Intent unIntent = getIntent();
        level = unIntent.getStringExtra("level");

        lvlText.setText("Niveau : "+level);

    }
}
